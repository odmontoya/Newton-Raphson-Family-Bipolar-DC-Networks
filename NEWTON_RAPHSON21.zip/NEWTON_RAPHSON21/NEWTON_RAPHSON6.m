%% POWER FLOW FOR BIPOLAR DC GRIDS
clc
clear
NE = 1;
Guardar = zeros(NE,1);
for kk = 1:NE
tic
% SYSTEM DATA
Vb = 1; % kV
Pb = 100;% kW
Rb = (Vb^2)/(Pb/1000);
%      [i j Rij(Ohm)]
LINES = [1   2   0.0530
    1   3   0.0540
    3   4   0.0540
    4   5   0.0630
    4   6   0.0510
    3   7   0.0370
    7   8   0.0790
    7   9   0.0720
    3   10  0.0530
    10  11  0.0380
    11  12  0.0790
    11  13  0.0780
    10  14  0.0830
    14  15  0.0650
    15  16  0.0640
    16  17  0.0740
    16  18  0.0810
    14  19  0.0780
    19  20  0.0840
    19  21  0.0820
    %7   19  0.0850
    %11  16  0.0370
    ];
% %       [i Pip Pin Pipn]
NODES = [1   0   0   0
    2   70  100 0
    3   0   0   0
    4   36  40  120
    5   4   0   0
    6   36  0   0
    7   0   0   0
    8   32  50  0
    9   80  0   100
    10  0   10  0
    11  45  30  0
    12  68  70  0
    13  10  0   75
    14  0   0   0
    15  22  30  0
    16  23  10  0
    17  43  0   60
    18  34  60  0
    19  9   15  0
    20  21  10  50
    21  21  20  0];
% Per-Unit transformation
LINES(:,3) = LINES(:,3)/Rb;
NODES(:,2:4) = NODES(:,2:4)/Pb;
%% INCIDENCE MATRIX
N = size(NODES,1);
L = size(LINES,1);
A = zeros(N,L);
for k = 1:L
    n = LINES(k,1); m = LINES(k,2);
    A(n,k) = 1; A(m,k) = -1;
end
A2p = zeros(2*N,2*L);
for m = 1:L
    for k = 1:N
        if A(k,m) == 1
            A2p(2*k-1:2*k,2*m-1:2*m) = eye(2);
        elseif  A(k,m) == -1
            A2p(2*k-1:2*k,2*m-1:2*m) = -eye(2);
        end
    end
end
%% PRIMITIVE ADMITANCE MATRIX
G = diag(1./LINES(:,3));
G2p = zeros(2*L,2*L);
for k = 1:L
    G2p(2*k-1:2*k,2*k-1:2*k) = G(k,k)*eye(2);
end
G2bus = A2p*G2p*A2p.';
%% Construction of M matrix
M = zeros(2*(N-1),2*(N-1));
for k = 1:N-1
    M(2*k-1:2*k,2*k-1:2*k) = [1 -1;-1 1];
end

%% MATRIZ SEPARATION
G2bds = G2bus(3:end,1:2);
G2bdd = G2bus(3:end,3:end);
Vdpn = ones(2*N-2,1);
Vdpn0 = ones(2*N-2,1);
PdpnY = ones(2*N-2,1);
PdpnD = ones(2*N-2,1);
Vspn = [1;-1];
for k = 1:N-1
    Vdpn0(2*k-1:2*k,1) = Vspn;
    PdpnY(2*k-1:2*k,1) = [NODES(k+1,2);NODES(k+1,3)];
    PdpnD(2*k-1:2*k,1) = [NODES(k+1,4);NODES(k+1,4)];
end
%% SUCESSIVE APPROXIMATION POWER FLOW METHOD
tol = 1e-10;
max_iter = 20;
%fprintf('Método de TRAUB Multivariado\n');
%fprintf('-----------------------------\n');
Error = [];
J = diag(G2bdd*Vdpn0 + G2bds*Vspn + diag(1./Vdpn0)*PdpnY)*M +...
        diag(M*Vdpn0)*(G2bdd - diag(1./(Vdpn0).^2)*diag(PdpnY));
Jinv = inv(J);
for k = 1:max_iter
    % Paso 1: Evaluar F(v)
    F = diag(M*Vdpn0)*(G2bdd*Vdpn0 + G2bds*Vspn + diag(1./Vdpn0)*PdpnY) + PdpnD;
    % Paso 3: Actualización de Traub
    v_new = Vdpn0 - Jinv*F;
    % Mostrar avance
    %fprintf('Iter %2d: ||F|| = %.3e, ||v_new - v|| = %.3e\n', ...
    %    k, norm(F, inf), norm(v_new - Vd0, inf));
    %semilogy(k,norm(v_new - v, inf),'*k')
    %hold on
    Error = [Error;k norm(v_new - Vdpn0, inf)];

    % Criterio de convergencia
    if norm(v_new - Vdpn0, inf) < tol
        %fprintf('\nConvergencia alcanzada en %d iteraciones.\n', k);
        break;
    end
    Vdpn0 = v_new;
end
    t1 = toc;
    Guardar(kk,1) = t1;
end
V = [Vspn;Vdpn0];
Ploss = V.'*(G2bus*V);
disp(Ploss*Pb);
% save NR6_21




