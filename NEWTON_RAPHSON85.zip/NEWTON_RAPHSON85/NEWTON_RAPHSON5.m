%% POWER FLOW FOR BIPOLAR DC GRIDS
clc
clear
NE = 1;
Guardar = zeros(NE,1);
for kk = 1:NE
tic
% SYSTEM DATA
Vb = 11; % kV
Pb = 1000;% kW
Rb = (Vb^2)/(Pb/1000);
%      [i j Rij(Ohm)]
LINES = [1   2 0.108 
2   3 0.163 
3   4 0.217 
4   5 0.108 
5   6 0.435 
6   7 0.272 
7   8 1.197 
8   9 0.108 
9  10 0.598 
10 11 0.544 
11 12 0.544 
12 13 0.598 
13 14 0.272 
14 15 0.326 
2  16 0.728 
3  17 0.455 
5  18 0.820 
18 19 0.637 
19 20 0.455 
20 21 0.819 
21 22 1.548 
19 23 0.182 
7  24 0.910 
8  25 0.455 
25 26 0.364 
26 27 0.546 
27 28 0.273 
28 29 0.546 
29 30 0.546 
30 31 0.273 
31 32 0.182 
32 33 0.182 
33 34 0.819 
34 35 0.637 
35 36 0.182 
26 37 0.364 
27 38 1.002 
29 39 0.546 
32 40 0.455 
40 41 1.002 
41 42 0.273 
41 43 0.455 
34 44 1.002 
44 45 0.911 
45 46 0.911 
46 47 0.546 
35 48 0.637 
48 49 0.182 
49 50 0.364 
50 51 0.455 
48 52 1.366 
52 53 0.455 
53 54 0.546 
52 55 0.546 
49 56 0.546 
9  57 0.273 
57 58 0.819 
58 59 0.182 
58 60 0.546 
60 61 0.728 
61 62 1.002 
60 63 0.182 
63 64 0.728 
64 65 0.182 
65 66 0.182 
64 67 0.455 
67 68 0.910 
68 69 1.092 
69 70 0.455 
70 71 0.546 
67 72 0.182 
68 73 1.184 
73 74 0.273 
73 75 1.002 
70 76 0.546 
65 77 0.091 
10 78 0.637 
67 79 0.546 
12 80 0.728 
80 81 0.364 
81 82 0.091 
81 83 1.092 
83 84 1.002 
13 85 0.819 
];
% %       [i Pip Pin Pipn] 
NODES = [ 1 0     0     0
 2 0     0     20.15
 3 100   0     80.70
 4 56    57.13 0
 5 200   100   0
 6 35.28 35.99 50.36
 7 0     17.25 0
 8 35.28 35.99 60.58
 9 35.60 700   80.92
10 0     200   0
11 56    57.13 0
12 0     80    90
13 90    80    45
14 35.28 35.99 70.26
15 35.28 35.99 40.35
16 35.28 135   66.98
17 112.2 114.3 100.5
18 56    57.13 400
19 56    57.13 20
20 35.28 35.99 300
21 35.28 140   305
22 35.28 35.99 60
23 56    150   57.13
24 0     35.28 35.99
25 35.28 35.99 100
26 0     56    57.13
27 220   150   350
28 56    250   57.13
29 0     100   150
30 35.28 0     35.99
31 35.28 35.99 0
32 0     350   0
33 14    14.28 25
34 0     0     0
35 0     0     100
36 35.28 0     35.99
37 56    60    57.13
38 56    57.13 50
39 0     56    57.13
40 35.28 0     35.99
41 20    0     0
42 35.28 50    35.99
43 35.28 35.99 0
44 35.28 35.99 0
45 100   35.28 35.99
46 50    35.28 35.99
47 14    14.28 20
48 0     20    0
49 0     0     50
50 36.28 0     37.01
51 56    57.13 0
52 60    0     30
53 35.28 70    35.99
54 56    60    57.13
55 76    0     97.13
56 14    80    64.28
57 96    70.13 20
58 0     100   0
59 36    57.13 50
60 56    87.13 0
61 36    57.13 60
62 25    58.13 0
63 14    14.28 10
64 0     0     100
65 25    50    75
66 80    97.13 66
67 0     0     0
68 0     0     0
69 26    37.13 50
70 0     40    0
71 35.28 76.55 35.99
72 56    27.13 0
73 60    0     0
74 56    100   57.13
75 35.28 12.46 35.99
76 76    97.13 0
77 14    34.28 50
78 56    12    57.13
79 35.28 85.99 0
80 56    57.13 60
81 90    0     150
82 56    107.5 0
83 25.28 65.99 125
84 124   144.4 0
85 20    20    20];
factor = 0.50;
% Per-Unit transformation
LINES(:,3) = LINES(:,3)/Rb;
NODES(:,2:4) = (factor)*NODES(:,2:4)/Pb;
%% INCIDENCE MATRIX
N = size(NODES,1);
L = size(LINES,1);
A = zeros(N,L);
for k = 1:L
    n = LINES(k,1); m = LINES(k,2);
    A(n,k) = 1; A(m,k) = -1;
end
A2p = zeros(2*N,2*L);
for m = 1:L
    for k = 1:N
        if A(k,m) == 1
            A2p(2*k-1:2*k,2*m-1:2*m) = eye(2);
        elseif  A(k,m) == -1
            A2p(2*k-1:2*k,2*m-1:2*m) = -eye(2);
        end
    end
end
%% PRIMITIVE ADMITANCE MATRIX
G = diag(1./LINES(:,3));
G2p = zeros(2*L,2*L);
for k = 1:L
    G2p(2*k-1:2*k,2*k-1:2*k) = G(k,k)*eye(2);
end
G2bus = A2p*G2p*A2p.';
%% Construction of M matrix
M = zeros(2*(N-1),2*(N-1));
for k = 1:N-1
    M(2*k-1:2*k,2*k-1:2*k) = [1 -1;-1 1];
end

%% MATRIZ SEPARATION
G2bds = G2bus(3:end,1:2);
G2bdd = G2bus(3:end,3:end);
Vdpn = ones(2*N-2,1);
Vdpn0 = ones(2*N-2,1);
PdpnY = ones(2*N-2,1);
PdpnD = ones(2*N-2,1);
Vspn = [1;-1];
for k = 1:N-1
    Vdpn0(2*k-1:2*k,1) = Vspn;
    PdpnY(2*k-1:2*k,1) = [NODES(k+1,2);NODES(k+1,3)];
    PdpnD(2*k-1:2*k,1) = [NODES(k+1,4);NODES(k+1,4)];
end
%% SUCESSIVE APPROXIMATION POWER FLOW METHOD
tol = 1e-10;
max_iter = 20;
%fprintf('Método de TRAUB Multivariado\n');
%fprintf('-----------------------------\n');
Error = [];
J = diag(G2bdd*Vdpn0 + G2bds*Vspn + diag(1./(M*Vdpn0))*PdpnD) +...
        diag(Vdpn0)*(G2bdd - diag(1./(M*Vdpn0).^2)*diag(PdpnD)*M);
Jinv = inv(J);
for k = 1:max_iter
    % Paso 1: Evaluar F(v)
    F = diag(Vdpn0)*(G2bdd*Vdpn0 + G2bds*Vspn + diag(1./(M*Vdpn0))*PdpnD) + PdpnY;
    % Paso 3: Actualización de Traub
    v_new = Vdpn0 - Jinv*F;
    % Mostrar avance
    %fprintf('Iter %2d: ||F|| = %.3e, ||v_new - v|| = %.3e\n', ...
    %    k, norm(F, inf), norm(v_new - Vd0, inf));
    %semilogy(k,norm(v_new - v, inf),'*k')
    %hold on
    Error = [Error;k norm(v_new - Vdpn0, inf)];

    % Criterio de convergencia
    if norm(v_new - Vdpn0, inf) < tol
        %fprintf('\nConvergencia alcanzada en %d iteraciones.\n', k);
        break;
    end
    Vdpn0 = v_new;
end
    t1 = toc;
    Guardar(kk,1) = t1;
end
V = [Vspn;Vdpn0];
Ploss = V.'*(G2bus*V);
disp(Ploss*Pb);
% save NR5_85




